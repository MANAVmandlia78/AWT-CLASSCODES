const express = require('express')
const fs = require('fs')
const app = express()
const port = 3000
const filePath = "todos.json"
function readData() {
    let data = fs.readFileSync(filePath)
    if (data) {
        return JSON.parse(data)
    } else {
        return []
    }
}
function saveData(data) {
    fs.writeFileSync(filePath, JSON.stringify(data))
}
app.use(express.json())
//fetch all todos
app.get("/", (req, res) => {
    let todos = readData();
    // logic
    res.json(todos)
})
//fetch todo with id
app.get("/:id", (req, res) => {
    // logic
    const id = req.params.id;
    const ind = todos.findIndex((todo) => todo.id == id)
    if (ind == -1) {
        return res.status(404).json({
            message: "No such data with id: " + id
        })
    }
    res.json({
        message: "Data found",
        data: todos[ind]
    })

})
//add todo 
app.post("/", (req, res) => {
    let todos = readData();
    // logic
    const title = req.body.title
    const newTodo = {
        id: Date.now(),
        title: title,
        isCompleted: false
    }
    todos.push(newTodo)
    saveData(todos)
    res.json({
        message: "Data added successfully",
        data: newTodo
    })
})
//toggle todo with id
app.get("/update/:id", (req, res) => {
    // logic
    const id = req.params.id;

    const ind = todos.findIndex((todo) => todo.id == id)
    if (ind == -1) {
        return res.status(404).json({
            message: "No such data with id: " + id
        })
    }
    todos[ind].isCompleted = !todos[ind].isCompleted
    res.json({
        message: "Data updated successfully with id: " + id,
        data: todos[ind]
    })
})
//update todo with id
app.put("/:id", (req, res) => {
    // logic
    const id = req.params.id;
    const title = req.body.title

    const ind = todos.findIndex((todo) => todo.id == id)
    if (ind == -1) {
        return res.status(404).json({
            message: "No such data with id: " + id
        })
    }
    todos[ind].title = title
    res.json({
        message: "Data updated successfully with id: " + id,
        data: todos[ind]
    })
})
//delete todo with id
app.delete("/:id", (req, res) => {
    // logic
    const id = req.params.id;
    const ind = todos.findIndex((todo) => todo.id == id)
    if (ind == -1) {
        return res.status(404).json({
            message: "No such data with id: " + id
        })
    }
    todos = todos.filter((todo) => todo.id != id)
    res.status(201).json({
        message: "data deleted with id: " + id
    })
})
app.listen(port, () => console.log(`Example app listening on port ${port}!`))
